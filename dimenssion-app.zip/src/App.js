import './App.css';
import CanvasEditor from "./components/canvas-editor";

function App() {
  return (
    <div className="App">
      <CanvasEditor/>
    </div>
  );
}

export default App;
