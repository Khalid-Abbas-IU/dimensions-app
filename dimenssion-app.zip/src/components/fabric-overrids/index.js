import {fabric} from "fabric";

// Override Functions

fabric.Object.prototype.set({
    // borderColor: '#9eba1b',
    cornerColor: '#333333',
    borderColor: '#333333',
    cornerSize: 12,
    hasControls:false,
    hasBorders:false,
    cornerStyle: 'circle',
});
